-- Ejecutar una vez desde MySQL Workbench antes del primer arranque.
CREATE DATABASE bookmarks CHARACTER SET utf8mb4;
