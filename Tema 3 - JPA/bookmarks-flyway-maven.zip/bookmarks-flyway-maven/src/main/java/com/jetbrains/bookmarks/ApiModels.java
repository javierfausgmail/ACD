package com.jetbrains.bookmarks;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import java.time.Instant;

// Los objetos de la API se separan de las entidades persistentes.
public final class ApiModels {
    private ApiModels() { }

    public record CategoryRequest(
            @NotBlank @Size(max = 255) String name) { }

    public record CategoryResponse(Long id, String name) {
        static CategoryResponse from(Category category) {
            return new CategoryResponse(category.getId(), category.getName());
        }
    }

    public record BookmarkRequest(
            @NotBlank @Size(max = 200) String title,
            @NotBlank @Size(max = 500)
            @Pattern(regexp = "https?://\\S+", message = "Debe ser una URL http o https") String url,
            @Positive Long categoryId) { }

    public record BookmarkResponse(
            Long id, String title, String url, String status,
            Instant createdAt, Instant updatedAt, Instant publishedAt,
            CategoryResponse category) {
        static BookmarkResponse from(Bookmark bookmark) {
            return new BookmarkResponse(bookmark.getId(), bookmark.getTitle(), bookmark.getUrl(),
                    bookmark.getStatus(), bookmark.getCreatedAt(), bookmark.getUpdatedAt(),
                    bookmark.getPublishedAt(), bookmark.getCategory() == null ? null
                    : CategoryResponse.from(bookmark.getCategory()));
        }
    }
}
