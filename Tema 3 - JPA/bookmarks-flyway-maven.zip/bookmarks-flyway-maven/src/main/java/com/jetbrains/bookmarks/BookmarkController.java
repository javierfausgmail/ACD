package com.jetbrains.bookmarks;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
import static com.jetbrains.bookmarks.ApiModels.*;

@RestController
@RequestMapping("/api/bookmarks")
public class BookmarkController {
    private final BookmarkService service;

    public BookmarkController(BookmarkService service) { this.service = service; }

    @GetMapping
    public List<BookmarkResponse> listar() { return service.listar(); }

    @GetMapping("/{id}")
    public BookmarkResponse consultar(@PathVariable long id) { return service.consultar(id); }

    @PostMapping
    public ResponseEntity<BookmarkResponse> crear(@Valid @RequestBody BookmarkRequest request) {
        BookmarkResponse response = service.crear(request);
        return ResponseEntity.created(URI.create("/api/bookmarks/" + response.id())).body(response);
    }

    @PutMapping("/{id}")
    public BookmarkResponse actualizar(@PathVariable long id, @Valid @RequestBody BookmarkRequest request) {
        return service.actualizar(id, request);
    }

    @PatchMapping("/{id}/publish")
    public BookmarkResponse publicar(@PathVariable long id) { return service.publicar(id); }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
