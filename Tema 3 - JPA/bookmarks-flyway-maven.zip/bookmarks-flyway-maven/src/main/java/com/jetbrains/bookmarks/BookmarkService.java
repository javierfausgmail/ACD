package com.jetbrains.bookmarks;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import static com.jetbrains.bookmarks.ApiModels.*;

@Service
@Transactional
public class BookmarkService {
    private final BookmarkRepository bookmarks;
    private final CategoryRepository categories;

    public BookmarkService(BookmarkRepository bookmarks, CategoryRepository categories) {
        this.bookmarks = bookmarks;
        this.categories = categories;
    }

    @Transactional(readOnly = true)
    public List<BookmarkResponse> listar() {
        return bookmarks.findAllByOrderByIdAsc().stream().map(BookmarkResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public BookmarkResponse consultar(long id) {
        return BookmarkResponse.from(buscar(id));
    }

    public BookmarkResponse crear(BookmarkRequest request) {
        Bookmark bookmark = new Bookmark();
        aplicar(bookmark, request);
        return BookmarkResponse.from(bookmarks.saveAndFlush(bookmark));
    }

    public BookmarkResponse actualizar(long id, BookmarkRequest request) {
        Bookmark bookmark = buscar(id);
        aplicar(bookmark, request);
        bookmarks.flush();
        return BookmarkResponse.from(bookmark);
    }

    public BookmarkResponse publicar(long id) {
        Bookmark bookmark = buscar(id);
        bookmark.publicar();
        bookmarks.flush();
        return BookmarkResponse.from(bookmark);
    }

    public void eliminar(long id) {
        bookmarks.delete(buscar(id));
    }

    private Bookmark buscar(long id) {
        return bookmarks.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "No existe ese marcador"));
    }

    private void aplicar(Bookmark bookmark, BookmarkRequest request) {
        Category category = request.categoryId() == null ? null
                : categories.findById(request.categoryId()).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "No existe esa categoría"));
        bookmark.setTitle(request.title());
        bookmark.setUrl(request.url());
        bookmark.setCategory(category);
    }
}
