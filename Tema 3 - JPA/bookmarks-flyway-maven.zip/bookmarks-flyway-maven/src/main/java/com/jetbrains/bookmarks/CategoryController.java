package com.jetbrains.bookmarks;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
import static com.jetbrains.bookmarks.ApiModels.*;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    private final CategoryRepository categories;

    public CategoryController(CategoryRepository categories) { this.categories = categories; }

    @GetMapping
    public List<CategoryResponse> listar() {
        return categories.findAllByOrderByIdAsc().stream().map(CategoryResponse::from).toList();
    }

    @PostMapping
    public ResponseEntity<CategoryResponse> crear(@Valid @RequestBody CategoryRequest request) {
        Category saved = categories.saveAndFlush(new Category(request.name()));
        return ResponseEntity.created(URI.create("/api/categories/" + saved.getId()))
                .body(CategoryResponse.from(saved));
    }
}
