CREATE TABLE bookmarks
(
   id         BIGINT NOT NULL AUTO_INCREMENT,
   title      VARCHAR(200) NOT NULL,
   url        VARCHAR(500) NOT NULL,
   created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
   updated_at DATETIME(6) NULL,
   CONSTRAINT pk_bookmarks PRIMARY KEY (id)
);
