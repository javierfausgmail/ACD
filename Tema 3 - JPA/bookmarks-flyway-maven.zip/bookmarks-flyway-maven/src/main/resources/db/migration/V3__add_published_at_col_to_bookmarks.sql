ALTER TABLE bookmarks ADD COLUMN published_at DATETIME(6) NULL;
