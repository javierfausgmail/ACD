CREATE TABLE categories
(
   id   BIGINT NOT NULL AUTO_INCREMENT,
   name VARCHAR(255),
   CONSTRAINT pk_categories PRIMARY KEY (id)
);

ALTER TABLE bookmarks
   ADD COLUMN category_id BIGINT;

ALTER TABLE bookmarks
   ADD COLUMN status VARCHAR(255) NOT NULL DEFAULT 'DRAFT';

ALTER TABLE bookmarks
   ADD CONSTRAINT fk_bookmarks_category
   FOREIGN KEY (category_id) REFERENCES categories (id);
