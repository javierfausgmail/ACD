package com.jetbrains.bookmarks;

import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import java.sql.DriverManager;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class MigrationUpgradeTest {
    @Test
    void actualizaDesdeV1ConservandoLosMarcadores() throws Exception {
        String url = "jdbc:h2:mem:upgrade-" + UUID.randomUUID() + ";MODE=MySQL;DB_CLOSE_DELAY=-1";
        Flyway.configure().dataSource(url, "sa", "").target("1").load().migrate();
        try (var connection = DriverManager.getConnection(url, "sa", "");
             var statement = connection.createStatement()) {
            statement.executeUpdate("""
                    INSERT INTO bookmarks(title,url)
                    VALUES ('Java','https://dev.java')
                    """);
        }
        Flyway latest = Flyway.configure().dataSource(url, "sa", "").load();
        assertEquals(2, latest.migrate().migrationsExecuted);
        try (var connection = DriverManager.getConnection(url, "sa", "");
             var statement = connection.createStatement();
             var rows = statement.executeQuery("SELECT * FROM bookmarks")) {
            assertTrue(rows.next());
            assertEquals("Java", rows.getString("title"));
            assertEquals("DRAFT", rows.getString("status"));
            assertNotNull(rows.getTimestamp("created_at"));
            assertNull(rows.getObject("category_id"));
            assertNull(rows.getTimestamp("published_at"));
            assertFalse(rows.next());
        }
        assertEquals(0, latest.migrate().migrationsExecuted);
    }
}
