package com.jetbrains.bookmarks;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class BookmarksApiTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired Flyway flyway;

    @Test
    void arrancaConLasTresMigracionesYNoLasRepite() {
        assertEquals(3, flyway.info().applied().length);
        assertEquals(0, flyway.migrate().migrationsExecuted);
    }

    @Test
    void permiteCrearConsultarActualizarPublicarYEliminar() throws Exception {
        String category = mvc.perform(post("/api/categories")
                .contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"Java\"}"))
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        long categoryId = json.readTree(category).get("id").asLong();
        String request = """
                {"title":"Spring Boot","url":"https://spring.io/projects/spring-boot","categoryId":%d}
                """.formatted(categoryId);
        String bookmark = mvc.perform(post("/api/bookmarks")
                .contentType(MediaType.APPLICATION_JSON).content(request))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("DRAFT"))
                .andExpect(jsonPath("$.createdAt").isNotEmpty())
                .andExpect(jsonPath("$.category.name").value("Java"))
                .andReturn().getResponse().getContentAsString();
        long id = json.readTree(bookmark).get("id").asLong();

        mvc.perform(get("/api/bookmarks/{id}", id)).andExpect(status().isOk());
        mvc.perform(put("/api/bookmarks/{id}", id).contentType(MediaType.APPLICATION_JSON)
                .content(request.replace("Spring Boot", "Documentación de Spring Boot")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.updatedAt").isNotEmpty());
        mvc.perform(patch("/api/bookmarks/{id}/publish", id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("PUBLISHED"))
                .andExpect(jsonPath("$.publishedAt").isNotEmpty());
        mvc.perform(get("/api/bookmarks")).andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
        mvc.perform(delete("/api/bookmarks/{id}", id)).andExpect(status().isNoContent());
        mvc.perform(get("/api/bookmarks/{id}", id)).andExpect(status().isNotFound());
    }

    @Test
    void rechazaDatosInvalidos() throws Exception {
        mvc.perform(post("/api/bookmarks").contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"\",\"url\":\"sin-protocolo\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.title").exists())
                .andExpect(jsonPath("$.errors.url").exists());
        mvc.perform(post("/api/categories").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void admiteMarcadoresSinCategoria() throws Exception {
        mvc.perform(post("/api/bookmarks").contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"JetBrains\",\"url\":\"https://www.jetbrains.com\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.category").isEmpty());
    }

    @Test
    void rechazaUnaCategoriaInexistenteSinInsertarElMarcador() throws Exception {
        mvc.perform(post("/api/bookmarks").contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"Java\",\"url\":\"https://dev.java\",\"categoryId\":999999}"))
                .andExpect(status().isNotFound());
        mvc.perform(get("/api/bookmarks")).andExpect(jsonPath("$.length()").value(0));
    }
}
