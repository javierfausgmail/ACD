# Bookmarks: proyecto Maven del tutorial de Flyway con MySQL

Proyecto completo correspondiente al estado final del [artículo adaptado para la asignatura](https://github.com/javierfausgmail/ACD/blob/main/Tema%203%20-%20JPA/Flyway%20con%20Spring%20Boot%20y%20MySQL.md), basado en el [artículo de Siva Katamreddy en The JetBrains Blog](https://blog.jetbrains.com/idea/2024/11/how-to-use-flyway-for-database-migrations-in-spring-boot-applications/).

Incluye las entidades `Bookmark` y `Category`, sus getters y setters, repositorios y las tres migraciones del artículo. Para poder utilizarlo y comprobar los datos también incluye una API REST de categorías y marcadores. No necesita Lombok, Docker ni variables de entorno.

## Preparar y ejecutar

Necesitas JDK 17 o 21, Maven 3.6.3 o posterior y MySQL Server 8.0/8.4 instalado y en ejecución en Windows. La versión de Spring Boot fijada para este ejemplo es 3.5.8.

1. Descomprime el proyecto y abre su `pom.xml` en IntelliJ IDEA como proyecto Maven. Espera a que descargue las dependencias.
2. Abre MySQL Workbench y ejecuta el contenido de `sql/crear-base.sql`:

   ```sql
   CREATE DATABASE bookmarks CHARACTER SET utf8mb4;
   ```

3. Edita `src/main/resources/application.properties` y escribe tus datos locales:

   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/bookmarks
   spring.datasource.username=root
   spring.datasource.password=TU_CONTRASENA_MYSQL
   ```

   El texto de contraseña es un marcador: sustitúyelo por la tuya. Si usas otro usuario o puerto, adapta esos valores. Utiliza una base vacía para la primera ejecución. Si ya has aplicado exactamente las migraciones del artículo a `bookmarks`, puedes usar esa misma base con su historial; si tienes tablas creadas por otro procedimiento, crea otra base vacía para este ejemplo.

4. Ejecuta `BookmarksApplication` desde el IDE o, desde la carpeta que contiene `pom.xml`:

   ```text
   mvn spring-boot:run
   ```

5. Abre [http://localhost:8080/api/bookmarks](http://localhost:8080/api/bookmarks). Inicialmente devuelve `[]`. Es una API que responde en JSON, no una aplicación con formularios HTML.

Flyway aplica V1, V2 y V3 al iniciar. Hibernate utiliza `validate` y comprueba el esquema resultante. La aplicación no borra datos ni vuelve a aplicar las migraciones en cada arranque.

## Probar las operaciones

Abre `peticiones.http` y ejecuta sus peticiones en orden con el cliente HTTP de IntelliJ IDEA. También puedes usar Postman o estas instrucciones de PowerShell:

```powershell
$categoria = Invoke-RestMethod -Method Post -Uri 'http://localhost:8080/api/categories' -ContentType 'application/json' -Body '{"name":"Java"}'
$datos = @{title='Spring Boot'; url='https://spring.io/projects/spring-boot'; categoryId=$categoria.id} | ConvertTo-Json
$marcador = Invoke-RestMethod -Method Post -Uri 'http://localhost:8080/api/bookmarks' -ContentType 'application/json' -Body $datos
Invoke-RestMethod -Uri 'http://localhost:8080/api/bookmarks'
Invoke-RestMethod -Method Patch -Uri "http://localhost:8080/api/bookmarks/$($marcador.id)/publish"
```

| Método | Ruta | Operación |
|---|---|---|
| GET | `/api/categories` | Listar categorías |
| POST | `/api/categories` | Crear categoría, con `name` |
| GET | `/api/bookmarks` | Listar marcadores |
| GET | `/api/bookmarks/{id}` | Consultar un marcador |
| POST | `/api/bookmarks` | Crear con `title`, `url` y `categoryId` opcional |
| PUT | `/api/bookmarks/{id}` | Actualizar título, URL y categoría; omitir `categoryId` retira la categoría |
| PATCH | `/api/bookmarks/{id}/publish` | Publicar y registrar `publishedAt` |
| DELETE | `/api/bookmarks/{id}` | Eliminar un marcador |

El alta establece `DRAFT` y `createdAt` desde Java. Al modificar una entidad se registra `updatedAt`. Publicar cambia el estado a `PUBLISHED` y establece la primera fecha de publicación. Los datos no válidos devuelven 400 y los identificadores inexistentes, 404.

## Relación con las migraciones del artículo

| Archivo | Efecto |
|---|---|
| `V1__create_bookmarks_table.sql` | Tabla de marcadores con título, URL y fechas |
| `V2__add_status_category_to_bookmarks.sql` | Tabla de categorías, relación y estado con valor predeterminado `DRAFT` |
| `V3__add_published_at_col_to_bookmarks.sql` | Fecha de publicación |

Las entidades entregadas contienen todos los campos de V3. No hay que ejecutar cada script manualmente: Flyway los aplica al arrancar. Tampoco hay que generar otras migraciones desde IntelliJ para esta primera ejecución; el proyecto ya las contiene.

Comprueba el resultado en MySQL Workbench:

```sql
USE bookmarks;
SELECT * FROM flyway_schema_history ORDER BY installed_rank;
SELECT * FROM categories;
SELECT * FROM bookmarks;
```

`@ColumnDefault` no inicializa los atributos Java; por eso el proyecto completa `createdAt` en `@PrePersist` y establece `status` en la entidad. Esto permite guardar registros válidos con JPA y conserva los valores SQL por defecto del tutorial.

## Pruebas y JAR ejecutable

```text
mvn test
mvn package
java -jar target/bookmarks-flyway-1.0.0.jar
```

Las pruebas utilizan H2 en modo de compatibilidad MySQL, solo durante los tests; no cambian tu servidor ni necesitan tu contraseña. Comprueban las tres migraciones, la actualización desde V1 sin pérdida de datos, el CRUD, la publicación y las validaciones. H2 no reproduce todos los detalles de MySQL: el funcionamiento en tu servidor se comprueba mediante el arranque y las peticiones anteriores.

Para el JAR, los datos de conexión son los que había en `application.properties` al ejecutar `mvn package`. Si los cambias, vuelve a empaquetar.

## Estructura

```text
bookmarks-flyway-maven/
├── pom.xml
├── README.md
├── peticiones.http
├── sql/crear-base.sql
└── src/
    ├── main/
    │   ├── java/com/jetbrains/bookmarks/
    │   │   ├── BookmarksApplication.java
    │   │   ├── Bookmark.java
    │   │   ├── Category.java
    │   │   ├── BookmarkRepository.java
    │   │   ├── CategoryRepository.java
    │   │   ├── BookmarkService.java
    │   │   ├── BookmarkController.java
    │   │   ├── CategoryController.java
    │   │   ├── ApiModels.java
    │   │   └── ApiExceptionHandler.java
    │   └── resources/
    │       ├── application.properties
    │       └── db/migration/                 V1, V2 y V3
    └── test/                                 pruebas y configuración aislada
```

Documentación de referencia: [integración de Flyway con Spring Boot](https://docs.spring.io/spring-boot/3.5/how-to/data-initialization.html).
